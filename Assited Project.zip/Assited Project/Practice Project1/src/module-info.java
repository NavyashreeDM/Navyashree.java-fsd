/**
 * 
 */
/**
 * 
 */
module Practice1 {
}
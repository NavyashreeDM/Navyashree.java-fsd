/**
 * 
 */
/**
 * 
 */
module Practice10 {
}
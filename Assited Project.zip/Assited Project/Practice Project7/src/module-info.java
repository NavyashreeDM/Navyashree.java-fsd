/**
 * 
 */
/**
 * 
 */
module Practice7 {
}
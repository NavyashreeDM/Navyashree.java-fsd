/**
 * 
 */
/**
 * 
 */
module Practice6 {
}
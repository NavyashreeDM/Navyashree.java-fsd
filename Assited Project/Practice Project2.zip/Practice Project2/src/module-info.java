/**
 * 
 */
/**
 * 
 */
module Practice2 {
}